import React from 'react';

export default React.memo(function header(){
    return(
        <>
            <div style={{position:"fixed",width:"100%",backgroundColor:"red",height:"20%",fontSize:"25pt", zIndex:"1"}}>
                123456
            </div>
        </>
    )
});