import React from 'react';
import {Accordion, Card, Button} from 'react-bootstrap'

export default React.memo(function menu() {
    return (
        <>
            <div style={{ position: "fixed", top: "20%", left: "0", width: "20%", backgroundColor: "white", height: "80%", zIndex:"1"}}>
                <div style={{position:"relative", width:"100%", height:"25%"}}>
                    <div style={{position:"relative", margin:"10px"}}>
                        <div style={{float:"left", width:"30%"}}>
                            <img alt="" src={require("../images/images.jpg")} style={{position:"relative", width:"100%"}}/>
                        </div>
                        <div style={{float:"left",width:"70%"}}>
                            <p style={{paddingLeft:"10px", marginBottom:"0"}}>姓名:XXXXXXX</p>
                            <p style={{paddingLeft:"10px", marginBottom:"0"}}>ID:XXXXXXX</p>
                        </div>
                    </div>
                </div>
                <Accordion>
                    <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="0">
                            Click me!
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="0">
                            <Card.Body>Hello! I'm the body</Card.Body>
                        </Accordion.Collapse>
                    </Card>
                    <Card>
                        <Accordion.Toggle as={Card.Header} eventKey="1">
                            Click me!
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="1">
                            <Card.Body>Hello! I'm another body</Card.Body>
                        </Accordion.Collapse>
                    </Card>
                </Accordion>
            </div>
        </>
    );
});