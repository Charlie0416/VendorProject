import React from 'react';
import './App.css';
import Header from './components/header';
import Body from './components/body';
import Menu from './components/menu';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <>
      <Header/>
      <Body/>
      <Menu/>
    </>
  );
}

export default App;
